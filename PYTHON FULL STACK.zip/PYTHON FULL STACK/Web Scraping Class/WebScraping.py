import requests
import pandas as pd
from bs4 import BeautifulSoup  # bs4-library beautifulsoup-module

response = requests.get("https://www.flipkart.com/mobiles/mi~brand/pr?sid=tyy,4io&otracker=nmenu_sub_Electronics_0_Mi") #link from browser
#print(response)  # if response get 200 it means success and gave permission.
soup=BeautifulSoup(response.content,'html.parser')
#print(soup)

#Data unstructured to structured 

print()
print("Mobile Names Data:")
names=soup.find_all('div',class_="_4rR01T") #<div class="_4rR01T">REDMI 10 Power (Power Black, 128 GB)</div>
name=[]
for i in names[0:20]:  # limited data 0 to data
    d=i.get_text()
    name.append(d)
print(name)


print()
print("Prices Data:")
prices=soup.find_all('div',class_="_30jeq3 _1_WHN1") #<div class="_30jeq3 _1_WHN1">₹10,499</div>
price=[]
for i in prices[0:20]:
    d=i.get_text()
    price.append(d)
print(price)



print()
print("Ratings Data:")
rates=soup.find_all('div',class_="_3LWZlK") # <div class="_3LWZlK">4.2<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div>
rate=[]
for i in rates[0:20]:
    d=i.get_text()
    rate.append(d)
print(rate)


#<img loading="eager" class="_396cs4" alt="REDMI 10 Power (Power Black, 128 GB)" src="https://rukminim2.flixcart.com/image/312/312/xif0q/mobile/e/y/b/-original-imageftfzx8gfkys.jpeg?q=70">
print()
print("Images Data:")
images=soup.find_all('img',class_="_396cs4")
image=[]
for i in images[0:20]:
    d=i['src']
    image.append(d)
print(image)


# <a class="_1fQZEK" target="_blank" rel="noopener noreferrer" href="/redmi-10-power-power-black-128-gb/p/itm97f5d2ec83588?pid=MOBGHDXFYKKZFZGV&amp;lid=LSTMOBGHDXFYKKZFZGVCWAYVV&amp;marketplace=FLIPKART&amp;store=tyy%2F4io&amp;srno=b_1_1&amp;otracker=nmenu_sub_Electronics_0_Mi&amp;iid=ff1b9b1d-82b0-46e2-8fd1-0859e3b84f9a.MOBGHDXFYKKZFZGV.SEARCH&amp;ssid=883v2rl4ww0000001704870574536"><div class="MIXNux"><div class="_2QcLo-"><div><div class="CXW8mj" style="height: 200px; width: 200px;"><img loading="eager" class="_396cs4" alt="REDMI 10 Power (Power Black, 128 GB)" src="https://rukminim2.flixcart.com/image/312/312/xif0q/mobile/e/y/b/-original-imageftfzx8gfkys.jpeg?q=70"></div></div></div><div class="_3wLduG"><div class="_3PzNI-"><span class="f3A4_V"><label class="_2iDkf8"><input type="checkbox" class="_30VH1S" readonly=""><div class="_24_Dny"></div></label></span><label class="_6Up2sF"><span>Add to Compare</span></label></div></div><div class="_2hVSre _3nq8ih"><div class="_36FSn5"><svg xmlns="http://www.w3.org/2000/svg" class="_1l0elc" width="16" height="16" viewBox="0 0 20 16"><path d="M8.695 16.682C4.06 12.382 1 9.536 1 6.065 1 3.219 3.178 1 5.95 1c1.566 0 3.069.746 4.05 1.915C10.981 1.745 12.484 1 14.05 1 16.822 1 19 3.22 19 6.065c0 3.471-3.06 6.316-7.695 10.617L10 17.897l-1.305-1.215z" fill="#2874F0" class="eX72wL" stroke="#FFF" fill-rule="evenodd" opacity=".9"></path></svg></div></div></div><div class="_3pLy-c row"><div class="col col-7-12"><div class="_4rR01T">REDMI 10 Power (Power Black, 128 GB)</div><div class="gUuXy-"><span id="productRating_LSTMOBGHDXFYKKZFZGVCWAYVV_MOBGHDXFYKKZFZGV_" class="_1lRcqv"><div class="_3LWZlK">4.2<img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMyIgaGVpZ2h0PSIxMiI+PHBhdGggZmlsbD0iI0ZGRiIgZD0iTTYuNSA5LjQzOWwtMy42NzQgMi4yMy45NC00LjI2LTMuMjEtMi44ODMgNC4yNTQtLjQwNEw2LjUuMTEybDEuNjkgNC4wMSA0LjI1NC40MDQtMy4yMSAyLjg4Mi45NCA0LjI2eiIvPjwvc3ZnPg==" class="_1wB99o"></div></span><span class="_2_R_DZ"><span><span>5,726 Ratings&nbsp;</span><span class="_13vcmD">&amp;</span><span>&nbsp;317 Reviews</span></span></span></div><div class="fMghEO"><ul class="_1xgFaf"><li class="rgWa7D">8 GB RAM | 128 GB ROM</li><li class="rgWa7D">17.02 cm (6.7 inch) Display</li><li class="rgWa7D">50MP Rear Camera | 5MP Front Camera</li><li class="rgWa7D">6000 mAh Battery</li><li class="rgWa7D">12 Months Warranty</li></ul></div></div><div class="col col-5-12 nlI3QM"><div class="_3tbKJL"><div class="_25b18c"><div class="_30jeq3 _1_WHN1">₹10,499</div><div class="_3I9_wc _27UcVY">₹18,999</div><div class="_3Ay6Sb"><span>44% off</span></div></div></div><div class="_13J9qT"><img height="21" src="//static-assets-web.flixcart.com/fk-p-linchpin-web/fk-cp-zion/img/fa_62673a.png"></div></div></div></a>

print()
print("Links Data:")
links=soup.find_all('a',class_="_1fQZEK")
link=[]
for i in links[0:20]: 
    d="https://www.flipkart.com"+i['href']
    link.append(d)
print(link)    

# TO store data in one
df=pd.DataFrame() # row columns
df["Names"]=name    # names-column name,name-row data
df["Prices"]=price
df["Ratings"]=rate
df["Images"]=image
df["Links"]=link 
print(df)


# Save data to csv
df.to_csv("Mobiles.csv")

