def add(a,b):
    print("sum",a+b)
def sub(a,b):
    return a-b
def mul(a,b):
    print(a*b)    