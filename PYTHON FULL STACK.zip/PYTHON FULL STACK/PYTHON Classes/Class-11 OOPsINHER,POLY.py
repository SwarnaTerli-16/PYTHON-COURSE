'''
# # inheritance
# # single (parent child)
# # multilevel(tree)
# # # multiple(two are more base classes)
# # # # hierarchical(one base with sibiling childs)



# Single Inheritance: 1 parent classs and 1  child class 
class Parent:
    def output(self):
         print('this is parent class')
class Child(Parent):
    def outputChild(self): # output
        print('this is child class')
i=Child()
i.output()
i.outputChild()

# Multi-Level Inheritance: one class inherits the another class
class GrandFather:
    def outputgf(self):
        print("This is gf class")
class Father(GrandFather):
    def outputf(self):
        print("This is father class")
class Child(Father):
    def outputc(self):
        print("This is child class")     
obj=Child() 
obj.outputgf() 
obj.outputf() 
obj.outputc()  


# Heirarchical Inheritance: 1 parent 2 childerns
class Father:#100cr
    def output(self):
        print('this is father class')
class Child1(Father):#50cr
    def outputf(self):
        print('this is child 1 class')
class Child2(Father):#50cr
    def outputChild(self):
        print('this is child  2 class')      
ice=Child1()
cream=Child2()
ice.output() #child 1 of parent
ice.outputf()
cream.output() # child 2 of parent
cream.outputChild() # child 2


# Multiple Inheritance: 2parents 1 child
class Father:
    def output(self):
        print("This is parent class")
class Mother:
    def outputM(self):
        print("This is mother class")
class Child(Father,Mother):
    def outputc(self):
        print("This is child class")
obj=Child()
obj.output()
obj.outputM() 
obj.outputc()    


# Topic POLMORPHISM
# Polymorphism: ONe task can be done in many forms
# poly  - many
# morph - forms
# EX: Female- mom,sis,friend,teacher,citizen..
# 1.method overloading 
# 2.method overridding

# 1.method overloading 
'''
# Two or more methods have the same name 
# but different numbers of parameters or
# different types of parameters, or both. 
'''
# Method Overloading Program: It produces error
# class example:
#    def add(self, a, b):
#       x = a+b
#       return x
#    def add(self, a, b, c):
#       x = a+b+c
#       return x
# obj = example()
# print (obj.add(10,20,30))
# print (obj.add(10,20))

# Program Without error
class example:
   def add(self, a = None, b = None, c = None):
      x=0
      if a !=None and b != None and c != None:
         x = a+b+c
      elif a !=None and b != None and c == None:
         x = a+b
      return x
obj = example()
print (obj.add(10,20,30))
print (obj.add(10,20))


# # ERROR
# class Methodoverlod:
#     def something(self,a,b,c):  
#         print(a,b,c)
# obj=Methodoverlod()
# obj.something(1,2,3)
# obj.something(1,2)  # Error bcoz args are not passed
# obj.something(1)
# obj.something()

# Without Error
class Methodoverlod:
    def something(self,a=None,b=None,c=None):
        print(a,b,c)
obj=Methodoverlod()
obj.something(1,2,3)
obj.something(1,2)
obj.something(1)
obj.something()

'''



# 2.Method Overridding: 
''' Method name should be same
    No of arguments should be same.
'''  
# class Methodoverri:
#     def display(self):
#         print("this is parent class")
# class Child(Methodoverri):
#     def display(self):
#         print("this is child class")            
# obj=Child()
# obj.display()


# Self- currentclass , 
# Super - parentclass-->childclass

#Super():
# To access both classes use super() method
class Methodoverri:
    def display(self):
        print("this is parent class")
class Child(Methodoverri):
    def display(self):
        print("this is child class")
        super().display()               
obj=Child()
obj.display()







