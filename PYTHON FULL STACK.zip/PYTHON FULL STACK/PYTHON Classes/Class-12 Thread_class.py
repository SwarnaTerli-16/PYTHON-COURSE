# '''
# Process:
# The process is a program (set of instructions) in execution.
# Process cannot share the memory.

# Multi Processing: More than one process.
# Multi Threading: More than one thread.


# Thread:
# Thread is light-weight processes
# Threads can be used to perform complicated tasks in the background without interrupting the main program.
# Threads can Share the memory.
# Threads are inside the process.



# Thread LifeCycle:
#new,runnable,runnning,dead

# run():is the entry point for a thread. (running)

# start():method starts a thread by calling the run method. (runnable)

# join([time]):waits for threads to terminate.   (dead)

# isAlive():method checks whether a thread is still executing.

# getName():method returns the name of a thread.

# '''



import threading
from threading import * 
from time import sleep     # sleep : to keep thread hold.

class First_thread(Thread):     # Thread- parent class, First_thread-child class
    def run(self):
        for i in range(1,10):
            print(i,"This is 1st Thread")
            sleep(2)          # it pause 2 seconds and run other thread parallel and gives firstthread output and then scnd_thread output.

class Second_thread(Thread):
    def run(self):
        for i in range(1,10):
            print(i,"This is 2nd Thread")
            sleep(2)
           
t1=First_thread()
t2=Second_thread()

# runs and gives the output but gives firstthread output and then secnd output.No equal priority.
#t1.run()
#t2.run() 

# t1.start(),t2.start()-gives priority and runs parallel but gives random thread output-this is thread concept.
t1.start()
print(t1.is_alive())
t2.start()
print(t2.is_alive())
t1.join()
t2.join()  # thread dies using join()
print(t1.is_alive())
print(t2.is_alive())

# There is no thread name so it contains default thread -main thread
print(threading.current_thread().getName())


