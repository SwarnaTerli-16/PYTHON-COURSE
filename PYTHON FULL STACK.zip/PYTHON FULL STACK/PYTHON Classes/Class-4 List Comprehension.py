'''
List Comprehension :
newlist = [expression for item in iterable if condition == True]
newlist = [ expression(element) for element in oldList if condition ]                 
'''


# #Program to print even or odd using List Comprehension
# list=["even" if i % 2 == 0 else 'odd' for i in range(10)]
# print(list) 

# # Using list comprehension to determine even or odd for numbers from 0 to 9
# result = [f"{i} is even" if i % 2 == 0 else f"{i} is odd" for i in range(10)]
# print(result)

# # List of numbers
# numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# # Using list comprehension to determine even or odd
# even_odd = ["Even" if num % 2 == 0 else "Odd" for num in numbers]
# # Printing the result
# for i in range(len(numbers)):
#     print(f"{numbers[i]} is {even_odd[i]}")


# #Program to print +ve or -ve using List Comprehension 
# l1=[f"{i} +ve" if i>0 == 0 else f"{i}-ve" for i in range(1,10)]
# print(l1)
     
# l=[1,0,2,-1,21,-3,120,-5,-0.5,1.0]
# l1=[f"{i} +ve" if i>=0 == 0 else f"{i}-ve" for i in l]
# print(l1)      

# #Program1
# fruits=["apple","banana","cherry","kiwi","mango"]
# newlist=[x for x in fruits if 'a' in x]
# print(newlist)
#    # OR
# newlist=[]
# for x in ["apple","banana","cherry","kiwi","mango"]:
#     if 'a' in x:
#         newlist.append(x)
# print(newlist)  

# #Program2 -- To print elements of an index
# s=[3,2,3,4,3]
# for x in range(len(s)):   #range(5)
#     if s[x]==3:
#         print(x)

#Program2 -- To remove same elements from list
str=[1,6,6,6,6,3,8,6,10]
n=[]
for i in str:   
    if i==6:
        str.remove(i)
    else:
        n.append(i)    
print(n)        


# key = [1, 6, 6, 6, 6, 6, 2, 4, 5, 5, 6, 3]
# n = []
# for i in key:
#     if i != 6:
#         n.append(i)

# print(n)

# DOUBT
str=[1,6,6,6,6,3,8,6,10]
for i in str:   
    if i==6:
        str.remove(i)
        print(i)     


my_list = [1, 6, 6, 6, 6, 3, 8, 6, 10]
# Create a new list without the occurrences of 6
new_list = [i for i in my_list if i != 6]
# Print the modified list
print("Modified list:", new_list) 
# Print the removed occurrences
removed_occurrences = [i for i in my_list if i == 6]
print("Removed occurrences of 6:", removed_occurrences)          
