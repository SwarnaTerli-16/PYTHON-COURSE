
print("This is My First Program")

n=input("enetr name:")
print(n)

m=input("enetr names:").split()
print(m)

a=input("enter nbrs:").split()
for i in a:
    n=int(i)
    print(n)

#Converting into list
a=10,20,27
b=[a]
print(b) 

#Converting into tuple
a=11,12,13
b=(a)
print(b) 

a=input("enter nbrs:").split()
m=[]
for i in a:
    n=int(i)
    print(n)
    m.append(n)
print(m)    

n=input("enter value")

