'''
#Function: It is a block of code which only runs when its called.
def myfun():
    print("This is function def")
myfun()   # fun calling   

def myfun(a):    #single parameter fun
    print("This is function def",a)
myfun(a=10)   # fun calling  or myfun(10) 

def myfun(a,b,c):  #Multiple parameters fun
    print("This is function def",a,b,c)
myfun(10,2.0,"Python")   # fun calling  

def c(a,b):
    print(a+b)
c(10,20) 
c(30,20)   # one time defining many times calling. code reusability

# Program - sum of two nbrs by taking values as input
def sum(a,b):
    sum=a+b
    return sum
a=int(input("enter  a value:"))
b=int(input("enter b value"))
c=sum(a,b)
print(c)

def l(name):
    print("Hi",name)
n=input("enter value:")
l(n)    
'''

# Arbitary Parameter(*values): to send mutliple arguments in single parameter and the data is  taken as tuple
def names(*values):  
    print("Hi",values)
names("navya","swarna","vasavi","swapna")    


# Keyword Arguments(**name): one prametr can send multiple arguments and the data is  taken as dictionary
def myfun(**name):  
    print("This is function def",name)
myfun(name="swarna",age="10")   # fun calling  

# Through List
def f1(name):
    print("hi",name)
f1([1,2,3,4,5])   

# Nested Functions
def outer_fun():
    print("This is outer fun")
    def inner_fun():
        print("This is inner fun")
    inner_fun()    
outer_fun()

