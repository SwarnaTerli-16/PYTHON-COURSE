# sunny={1:'names','s.no':2,11:True}
# print(sunny)
# print(type(sunny))

# print(sunny[1])
# print(sunny['s.no'])
# print(sunny[11])

# #updating value
# sunny[1]="swarna"
# print(sunny)


# #Methods
# #get()- get value using key
# aswini={"sno":1,"name":"sunny","phone":[12,32]}
# print(aswini.get("sno"))
# #keys()
# print(aswini.keys())
# #values()
# print(aswini.values())
# #items()
# print(aswini.items()) 
# #update 
# aswini.update({"name":"bunny"})
# print(aswini)
# aswini.update({"food":"biryani"})
# print(aswini)
# #pop
# aswini.pop("sno")
# print(aswini)
#For loop with dict
aswini={"sno":1,"name":'s',1:25}
for i in aswini.items():
    print(i)
# OR
aswini={"sno":1,"name":'s',1:25}
for i,j in aswini.items():
    print(i,j)
 # OR
aswini={"sno":1,"name":'s',1:25}
for i in aswini:
    print(i,aswini.get(i))    

#Nested Dictionary
v={1:"a",2:"b",3:{1:"aa"}}
print(v)
print(v[3])
print(v[1])
print(v[3][1])
