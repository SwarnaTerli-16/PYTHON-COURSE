#int
a=12            
print(type(a))
b=-12              #int
print(type(b))

#float
c=2.2
print(type(c))
d=-2.2
print(type(d))

#complex
s=1+2j
print(type(s))

#boolean
e=True
print(type(e))
f=False
print(type(f))

#Type Conversion
m=120
print(float(m))   # int---> float,No data loss - Implicit Conversion

n=121+.88
print(int(n))     # float--->int, data loss - Explicit Conversion


n=122+.34
print(complex(n))   #(122.34+0j)