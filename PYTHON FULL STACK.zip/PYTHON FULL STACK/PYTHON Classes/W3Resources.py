


# user=int(input("enter a guess beweeen 1 to 9:"))
# gn=[1,2,3,4,5,6,7,8,9]
# while(True):
#     if user not in gn:
#         print("Wrong Guess!")
#         user=int(input("enter a guess beweeen 1 to 9:"))
            
#     else:
#         print("Well Guess")
#         exit()        
          
# n=input("enter word")
# print(n[::-1])

# l=[1,2,3,4,5,6,7,8,9]
# ce=0
# co=0
# for i in l:
#     if i%2==0:
#         ce=ce+1
#     else:
#         co=co+1
# print("Number of even:",ce)           
# print("Number of odds:",co)

          


