#1) class(template)
'''
1.we will define class by using 'class' keyword
2.class is a blue print to create a objects
3.collection of objects is called class
4.t is a logical entity that has some specific attributes and methods.
'''
#ex: employee 
#if you have an employee class, then it should contain an attribute and method, i.e. an email id, name, age, salary, etc.
#Class Syntax: 
# class ClassName:
#    class body

# Inside the class we can write constructors,functions,variables
# class Pramod:# class defination
#     # constructors
#     # functions
#     # variables


#2) object:It is an instance of class
# physical entity(real)
'''
1.an instance of a class
2.memory is created when object is declared
'''
#ex: table,pen,orange
#syntax: obj_name=class_name(arguments)
#Using object we can access variables and methods
'''
Syntax: 
Accessing Variable: object.variable
Accessing Method: object.method()   # using object - accesing variable and methods
''' 

#3) Wt is attribute and methods?
# attribute (variable) data members
'''
age=20 
color='blue'
'''
# method(behaviour) or functions , member functions
'''
eat() 
sleep()
'''

#4) self keyword:Self represents the instance of the class. By using the “self” we can access the attributes and methods of the class in Python
'''
we can access the attributes and methods of the class(current class only)
'''
'''
#5) Program1: Without Object
class karthik():  #class definition
    def output():
        print("This is Class")
    output()   


# 6)with object - we should use self
class karthik():  #class definition
    def output(self):
        print("This is Class")
obj1=karthik()       # Object creation   - syntax: obj_name=class_name()
obj1.output()        # To access methods - syntax: object_name.method_name()  

    

class Shiva():                  # Class definition
    a=10                        # class attribute
    def show(self):  # class functions
        print("this is class")
kiran=Shiva()                    # obj creation: # obj name=class name()
print(kiran.a)                   # Accesing variable: object.variable
kiran.show()                     # Accessing Mrthod: object.method()   # using object accesing variable and methods



class Shiva():   # Class definition
    a=10         # class attribute
    def show(self):  # class functions
        return "this is class"
kiran=Shiva()               # obj creation : # obj name=class name()
print(kiran.a)              # object.variable
print(kiran.show())         # object.method()                           


# Creating different objects
class Srilekha(): # class defination
    a=10
    def ClassMethod(self):
        print("this is class")
# Obj name=Class name()
kiranobj1=Srilekha()
kiranobj=Srilekha() # object declaration
kiranobj.ClassMethod()
kiranobj.a             # NO 10 in output  becoz no print
print(kiranobj.a)


# Using Self
class Kiran(): # class keyword class name
    a=10 # data member
    def Output(self): # method(self)
        print(self.a)
obj=Kiran()  # declaring of object 
obj.Output() # using object we can call the methods  

'''

# Two objects
class Naveen():
    a=10 #attribute
    def display(self):
        print(self.a)
    
ram=Naveen()  # object declaration
syam=Naveen()
ram.display()  # object name.method name ()
syam.display()

