# Q: Difference between Module, Package, Library, Framework 

#MPLF

# A:
# Module is a file which contains various Python functions and global variables. It is simply just .py extension file which has python executable code.

# Package is a collection of modules.

# Library is a collection of packages.

# Framework is a collection of libraries. This is the architecture of the program.