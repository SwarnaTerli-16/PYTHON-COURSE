'''
List: List is ordered,mutable,allow duplicates
'''

# swarna=[] #Empty List    
# print(type(swarna))

# swara=list() #built-in fun
# print(type(swara))

# # list()-should not give values inside .No values should given
# #l=list(1,2.2)
# #print(l)

# # List
# l=list([1,2.2])
# print(l)

# #Converting into List
# a=10,20,27
# b=[a]
# print(b) 

# l1=[1,2.2,'python',False]
# print(l1)

# #slicing
# k=[1,2.5,3.0,'rk','a',9]
# print(k[1:5])

# # Negative Indexing
james=[7,3,5,3,34,64,'True']
print(james[-2])

# #slicing
# #[start:stop:skip]

# print(james[:])    #total data
# print(james[::])   #total data
# print(james[:5])   #data left side
# print(james[5:])   #data right side
# print(james[::-1]) #reverse
# print(james[:-1])  #last elemnt skip
# print(james[0:5])
# print(james[0:5:2])
# print(james[0:5:-2])  #empty list forwarding no negative indexing
# print(james[5:0:-2])  
# print(james[5:0])  #Emptylist -becoz skip must be used when forwarding back 
print(james[-1:-5:-2])
print(james[-1:-5:2]) #emptylist
print(james[-5:-1:2])



