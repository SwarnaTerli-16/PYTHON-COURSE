#Lambda Function(Single line function) : It is a Anonymous function- unknown small function takes many arguments but takes only one expression
# syntax: lambda arguments :expression
x= lambda a,b,c : a+b+c
print(x(10,20,20))

#Program
l1=[4,32,65,48,97,16]
l2=[]
for i in l1:
    t = lambda a : a+1
    l2.append(t(i))
print(l2) 

'''
Filter():It filters the given sequence with the help of a function that tests each element in the sequence to be true or not.
syntax: filter(function,sequence)
Parameters:
function: fun that tests if each element of a sequence true or not.
sequence: sequence which needs tob e filtered it can be sets,tuples,lists or containers of any iterators.
Returns:return an iterator that is already filtered

'''
#Filter : Only true data accepts. No data structure change
ages=[5,12,17,18,24,32]
def myfun(x):
    if x<18:
        return False
    else:
        return True
adults = filter(myfun,ages) # there is no for loop -but for loop is done internally
                            #ages=[5,12,17,18,24,32] myfun takes each elemnt from list
print(list(adults))
#print(adults) -error becoz filter takes list,tuple etc

ages=[5,12,17,18,24,32]
def myfun(x):
    if x>=18:
        return True
    else:
        return False
adults = filter(myfun,ages) 
print(list(adults))



#Map(): It is used to return a list of results after applyiing agiven function to each item of an iterable(list,tuple)
#Syntax:
#map(function,iterable)

#Map(): Takes any data. Changes data structure
def calculateAddition(n):
    return n+n
numbers =(1,2,3,4)
result=map(calculateAddition,numbers)
print(list(result))


#reduce(): As the name dscribes,applies a given function to the iterables and returns a  single value.
#syntax: reduce(function,sequence)

from functools import reduce
d=reduce(lambda a,b:a+b,[23,21,45,98])
print(d)

'''
Generator function:
Generator function: It is defined like a normal function 
but whenever it needs to generate a value ,
it does so with the yield keyword rather than return.
If the body of a def contains yield,the function automatically becomes a generator function.

Return statement: It returns a value and terminates the whole function and only return statement can be usd in the function.
Yeild statement: It can returns many statemnets using yield statement. It doesnt terminate the fun.It goes to puase mode.

'''

def simpleGenerator():
    yield 1
    yield 2
    yield 3
x = simpleGenerator()
# Iterating over the generator object using next
print(x.__next__())
print(x.__next__())
print(x.__next__())


def even(x):
    if x%2==0:
        print(x)
#diff bw filter and map
nums=[11,22,33,44,55]
#map = list(map(lambda x: x**2,nums))
#print(list(map))
filter = list(filter(lambda x: x%2==0,nums))
print(filter)                

