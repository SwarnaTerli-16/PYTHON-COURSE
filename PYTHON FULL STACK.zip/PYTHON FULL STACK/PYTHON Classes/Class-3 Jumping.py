
# #BREAK
# for j in "python":
#     if j=="t":
#         break
#     print(j)

# #CONTINUE
# print()
# for k in "python":
#     if k=="o":
#         continue
#     print(k)

# #PASS
# if True:
#     pass

for i in range(0,10):
    if i==5:
        pass
    print(i)

# Print table using for loop
for i in range(1,11):
        print(2,"x",i,"=",2*i)

# #Nested for loop  
# Printing 1 to 1000 tables  
# print()
# for i in range(1,1001): # 1to1000 tables
#     for j in range(1,11): # upto 10
#         print(i,"x",j,"=",i*j,end=" ")
#     print()    

# #Program
# user="swarna"
# password="swara"
# user_name=input("enter username:")
# pw=input("enter password:")
# if user==user_name and password==pw:
#     print("success")
# else:
#     print("try again")    
        

        