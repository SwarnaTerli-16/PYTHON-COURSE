'''
from Fun1 import add,sub,mul
add(1,2)
sub(1,2)
mul(1,2)
'''
# OR
from Fun1 import *
add(1,5)
d=sub(10,5)
print(d)