# # # __init__

# # '''
# # __init__ function: used to initialize the attributes of an object as soon as the object is formed.
# # In Python the __init__() method is called the constructor
# init is used as method or constructor.
# # Constructors are generally used for instantiating an object. 
''' The task of constructors is to initialize(assign values)
to the data members of the class when an object of the class 
is created.
'''
# # and is always called when an object is created
# # does'nt support multiple constructor
# # '''

# self: 
#1.we can access variables within class --> syntax: obj.variable : print(obj.a)
#2. To access variables of class by using self -> syntax self.variablename: print(self.a)

#init uses:
#1)To intialize variables and that variables are used in another method of same class. (# init: the data variables in one fun used in another fun )
#2) THe parameters(variables) used in init method, the variables values is sent using object creation (p=Prakash(1,2,3)  # for init the args are passed here)
#Accessing Variables:The data(variables) in one fun are also used in another fun using init
#Accesing Methods:No need to call __init__ becoz init calls automatically.

'''
class Prakash():
    def __init__(self,a,b,c):   # to access method we use syntac obj.method_name by using init no need to use syntax becoz init obj is created no need to call init
        self.ff=a
        self.vv=b
        self.dd=c
        print(a)   # a accessed without self becoz same fun
    def Output(self):
        print(self.ff,self.vv,self.dd) # init: the variables/data in one fun used in another fun 
p=Prakash(1,2,3)  # for init the args are passed here
p.Output()
'''

'''
class Mobiles():
    def __init__(self,Mobile_name,Mobile_Ram,Mobile_battery,Mobile_Price):
        self.a=Mobile_name
        self.c=Mobile_Ram
        self.d=Mobile_battery
        self.e=Mobile_Price

    def Mobile_Data(self):
        print("Mobile Name:",self.a)
        print("Mobile Ram:",self.c)
        print("Mobile Battery:",self.d)
        print("Mobile Price:",self.e)
Mobiles_obj=Mobiles("Apple","8gb","6000mah","40000")
Mobiles_obj.Mobile_Data()
'''
# OR 


class Mobiles():
    def __init__(self,Mobile_name,Mobile_Ram,Mobile_battery,Mobile_Price):
        self.a=Mobile_name
        self.c=Mobile_Ram
        self.d=Mobile_battery
        self.e=Mobile_Price

    def Mobile_Data(self):
        print("Mobile Name:",self.a)
        print("Mobile Ram:",self.c)
        print("Mobile Battery:",self.d)
        print("Mobile Price:",self.e)
                            
name=input("Enter the Mobile Name:")
ram=input("Enter the Mobile Ram:")
bat=input("Enter the Mobile Battery:")
Price=float(input("Enter the Mobile Price:"))

Mobile_obj=Mobiles(name,ram,bat,Price)
Mobile_obj.Mobile_Data()
 
# OR
'''   
class Mobiles():
    def __init__(self,Mobile_name,Mobile_Ram,Mobile_battery,Mobile_Price):
        self.a=Mobile_name
        self.c=Mobile_Ram
        self.d=Mobile_battery
        self.e=Mobile_Price

    def Mobile_Data(self):
        print("Mobile Name:",self.a)
        print("Mobile Ram:",self.c)
        print("Mobile Battery:",self.d)
        print("Mobile Price:",self.e)

while True:                             
    name=input("Enter the Mobile Name:")
    ram=input("Enter the Mobile Ram:")
    bat=input("Enter the Mobile Battery:")
    Price=float(input("Enter the Mobile Price:"))

    Mobile_obj=Mobiles(name,ram,bat,Price)
    Mobile_obj.Mobile_Data()
'''  
  