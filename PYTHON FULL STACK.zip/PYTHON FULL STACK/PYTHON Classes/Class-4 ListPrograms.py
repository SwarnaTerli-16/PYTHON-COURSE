#1) Given a list of nbrs remove all odd numbersfrom the list.
# l=[1,2,3,4,5,6,7,8,9,10]
# l1=[]
# for i in l:
#     if i%2==0:
#         l1.append(i)    
# print(l1)                
 # OR Using List Comprehension
# l=[1,2,3,4,5,6,7,8,9,10]
# l1=[i for i in l if i%2==0]
# print(l1)

#2) Find the nbrs from 1-1000 that are divisible by 7.
# l=[i for i in range(1,1000+1) if i%7==0]
# print(l)

#3) Find the nbrs from 1-1000 that have a 3 in them.
# l=[i for i in range(1,1000+1) if '3' in str(i)]
# print(l)