
# Time
import time
current_time = time.localtime()
formatted_time = time.strftime("%H:%M:%S", current_time)
print(formatted_time)

# Datetime
import time
current_time = time.localtime()
formatted_time = time.strftime("%Y-%m-%d %H:%M:%S", current_time)
print(formatted_time)

import datetime  
#returns the current datetime object     
print(datetime.datetime.now())    