a=1
b=2
def add(a,b):
    return a+b
add(1,2)