# #String:It is a collection of characters.it is immutable
# suresh='python'  #suresh='it's' - 's not accepted
# durga="python"   #durge="it's"  -'s accepted
# madhu='''python'''
# print(type(suresh),type(durga),type(madhu))

# #Methods
# #variable.method
# #lower()
# sruthi="PYTHON"
# print(sruthi.lower())
# #upper()
# s="python"
# print(s.upper())
# #count
# james="my fav hero is hero"
# print(james.count("hero"))
# #index
# j="my fav hero is hero"
# print(j.index("my"))
# print(j.index('m'))
# print(j.index('y'))
# print(j.index("fav"))
# print(j.index("hero"))
# #find
# print(j.find("hero"))
# print(j.find("swarna")) #it gives -1 instead of error
# #print(j.index("swarna"))  #it gives error 

# print(j.startswith("my"))
# print(j.startswith("m"))
# print(j.startswith("hero"))
# print(j.endswith("hero"))
# print(j.endswith("h"))
# print(j.endswith('o'))
# #program -prints ends with in
# websites=["abc.com","xyz.in","pythonlife.in"]
# in_websites=[]
# for i in websites:
#     if i.endswith("in"):
#         in_websites.append(i)
# print(in_websites)   

# #format -it is a placeholder .values inserted in the placeholder.
# sai="hii {} thinnara? {}".format("sara","bye")
# print(sai)

# #format
# names=["ridhi","jiya","idiot"]
# for x in names:
#     print("hii {} thinnara?".format(x))

#isalnum  -alphanumeric
# satya="kiran"
# print(satya.isalnum())    #True
# satya="123"
# print(satya.isalnum())  #True
# satya="kiran123"
# print(satya.isalnum())  #True
# satya="2.2"      # takes data as float  #False
# print(satya.isalnum())    

# #isalpha() -alphabets
# satya="kiran"
# print(satya.isalpha()) 
# satya="12334"
# print(satya.isalpha())
# satya="12334"   #it takes data as int only
# print(str(satya.isalpha()))

#Program
# d=" this is book  "
# print(len(d))
# #strip -remove spaces
# s=d.strip()
# print(len(s))
# print(d)
# #left strip
# s=d.lstrip()
# print(len(s))
# #right strip
# s=d.rstrip()
# print(len(s))

# #title()
# f="a moment of self judgment"
# print(f.title())

# #replace()
# shaik="this is my book" 
# v=shaik.replace(" is"," are").replace('this',"that")
# print(v)
# shaik="this is is my book" 
# v=shaik.replace(" is"," are",1) # 1- first occurrence
# print(v)

# #split -convert string into list
# d="this is python split"
# f=d.split()
# print(f)
# #Program
# d="this is string class"
# f=d.split()
# n=[]
# for i in  f:
#     if i=="is":
#         i="are"
#         n.append(i)
#     else:
#         n.append(i)    
# print(n)
# #join
# d="this is string class"  #str --> split --> list --> used join --> changed to string
# print(d)
# c=d.split()
# print(c)
# s="*".join(c)
# print(s)

# a="this is swarna"
# print(a)
# b="*".join(a)
# print(b)


# converting list into string
my_list = ['H', 'e', 'l', 'l', 'o']
separator = ''
my_string = separator.join(my_list)
print(my_string)
# OR
# List of characters
my_list = ['H', 'e', 'l', 'l', 'o']
# Convert list to string
my_string = ''.join(my_list)
# Print the resulting string
print(my_string)

