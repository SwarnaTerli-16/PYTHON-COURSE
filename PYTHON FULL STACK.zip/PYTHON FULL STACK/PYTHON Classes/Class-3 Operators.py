#Arithmetic Operators
a=10
b=5
print(a+b)
print(a-b)
print(a*b)
print(a%b)
print(a/b)
print(a//b)

#Relational Operators
print()
a=10
b=20
print(a<=b)
print(a-b)
print(a*b)
print(a%b)
print(a/b)
print(a//b)

#Assignment Operators
print()
a=10
b=4
a+=b
print(a)
a*=b
print(a)
a%=b
print(a)
a/=b
print(a)
a=b
print(a)

#Logical Operators
print()
a=5
b=6
print(a<b and a>b)
x=12
y=15
print(x==y or x<y)
i=True
j=False
print(not i)
print(not j)

i=true
print(not i)
