#IF STATEMENT
if 2>1:
    print("This is IF Statemnet")

#IF-ELSE STATEMENT
if 2>0:
    print("This is IF Statemnet")   
else:
    print("This is IF-ELSE Statemnet")   

#ELIF STTAEMENT 
a=10
b=20
c=3 
if a>b:
    print(a)
elif b>c:
    print(b)
else:
    print(c)          

#NESTED-IF STATEMENT
if 30>20:
    print("This is OUTER-IF Statemnet")    
    if 10>5:
        print("This is INNER-IF Statemnet")
    else:
        print("This is INNER ELSE Statemnet")    
else:
    print("This is OUTER-ELSE Statemnet")


#Short Hand IF STATEMENT
if 100>20:print("if statement")


#Short Hand IF-ELSE STATEMENT
print("This is if statement") if 10<20 else print("This is else statement")

