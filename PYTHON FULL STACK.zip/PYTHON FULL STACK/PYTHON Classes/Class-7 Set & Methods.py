# Set- unordered,changeable(mutable),unindex,No duplicate
se={}
print(se)
s={12,34,4}
print(s)
print(type(s))
#unindexed
#print(s[0])
#unorderd
a={23,4,56,3,122,89,654,232,456,78,69}
print(a)
#No duplicates
b={1,2,3,4,2,7,6,3}
print(b)

#Methods
#add()
c={10,20,30,10,90,46,76,35}
c.add(11)
print(c)
#duplicate using add()
d={100,200,300,400}
d.add(200)
print(d)

#update()
sunny={1,22,342,1,2,334,2,2,11,2,1,1,2,3}
sunny.update({1,2,3,4,5,6,7})
# tuple in update method
print(sunny)
sunny={1,22,342,1,2,334,2,2,11,2,1,1,2,3}
sunny.update((1,2,3,4,5,6,7))
print(sunny)
# list in update method
sunny={1,22,342,1,2,334,2,2,11,2,1,1,2,3}
sunny.update([1,2,3,4,5,6,7])
print(sunny)
# string in update method
sunny={1,22,342,1,2,334,2,2,11,2,1,1,2,3}
sunny.update([1,2,3,4,5,6,7,"Python"])
print(sunny)
#remove()
sunny.remove(342)
print(sunny)
#pop()  -no indexing-particular element we cannot delete using pop() in set
i={1,233,234,5,6,0,-1,34,2,4.6,4,7,8,9}
i.pop()
print(i)
#clear()
v={1,2,3,4,5,6}
v.clear()
print(v)
#copy()
w={1.5,2.5,3.5,4.5,5.5}
x=w.copy()
print(x)
w.add(6.5) #adding data doesnt change the original data
print(w)
print(x)

