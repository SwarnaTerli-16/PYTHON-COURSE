# #Tuple
# m=(1,"KS",3.0,'a')
# print(m)

# #Converting into tuple
# a=11,12,13
# b=(a)
# print(b) 

# #index : doesnt work as it is unchangeable
# print(m[0])
# #Unchangeable Immutable
# #m[0]="s"
# #print(m)

# #Built-In-Methods
# #methodname(var)
# m=(1,2,34,5) # no char or strings
# print(max(m))
# print(min(m))
# print(sum(m))
# print(len(m))
# print(list(m))

# #tuple Operations
# #variable.method()
t1=(1,2,3)
t2=(4,5,3)
# print(t1+t2)

#zip
# s=zip(t1,t2)
# print(tuple(s))

# #Program to add two tuples #zip() -it zips two tuples
# s=zip(t1,t2)
# print(tuple(s))
# new=[]
# for i,j in zip(t1,t2):
#     new.append(i+j)
# print(tuple(new))  
#         # or
tuple1 = (1, 2, 3)
tuple2 = (4, 5, 6)
result = []
for elem1, elem2 in zip(tuple1, tuple2):
    # Perform an operation on elements from both tuples
    operation_result = elem1 + elem2  # Example: Adding elements
    result.append(operation_result)
print(result)

# #Repetition
# d=(1,2,3)
# print(d*10)

# #Memebership Operators
# d=(1,2,34,2,45,6,78,5,9)
# print(2 in d) 
# print(45 not in d)   

# #Identity Operators
# k=(1,21,34,2,45,6,78,5,9)
# d=(1,2,34,2,45,6,78,5,9)
# print(k is d)
# print(d is not k)

# # Tuple for loop
# d=(1,2,34,2,45,6,78,5,9)
# for i in d:
#     print(i) 

a=(1,)
print(a)

a=(1)
print(a)

# Conversion
# string into tuple
a="python"
b=(a)
print(tuple(b))

a=[1,2,3,4]
b=(a)
print(b)