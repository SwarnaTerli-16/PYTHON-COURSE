 #syntax: variable.method()
'''
LIST METHODS:
append    len     
copy      min
clear     max
count     pop
extend    remove
insert    reverse
index     sort
'''
#append
s=[1,2,3,4,5,6]
s.append(7)        #append-adds elemnt at end
print(s)
s.append(["s",11])    #append (sublist) -adds multiple data as sublist
print(s)
#extend
s1=[10,20,30,40,50,30]  
s1.extend([60,70])   #extend -adds multiple data as single elements to the list 
print(s1)
#count
print(s1.count(30))
#index
print(s1.index(40)) 
print(s1.index(30))  #first occurrence index gives
#len
print(len(s1)) 
#clear
s1.clear()
print(s1)

aparna=[1,2,3,4,5,6,7,8]
a=aparna
print(id(a))     #to know address of a varible - use id() fun
print(id(aparna))
print(a==aparna)
#copy
b=aparna.copy()
print(b)
#insert
j=[12,3,4,45,5]
j.insert(0,"KS")
print(j)
#POP
k=[11,23,12,56,78]
k.pop()
print(k)
k.pop(0)
print(k)
#remove
k.remove(12)
print(k)
#reverse
l=[0,1,2,3,4,5]
print(l.reverse())  #output-none
#reverse
l=[0,1,2,3,4,5]
l.reverse()
print(l)
c=[230,45,32,56,7899,12]
c.sort()
print(c)
