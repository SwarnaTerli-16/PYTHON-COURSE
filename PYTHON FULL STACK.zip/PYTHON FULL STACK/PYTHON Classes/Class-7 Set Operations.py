#Set Operations
#var1.method(var2)
#Union -all elemnts 
set1={1,2,3,4,5}
set2={4,5,6,7,8}
print(set1.union(set2))
#intersection -common elemnts
print(set1.intersection(set2))
#difference- removes common elemnts and print set1 elements
print(set1.difference(set2))
#difference- removes common elemnts and print set2 elements
print(set2.difference(set1))
#symmetric_difference -removes common elemnts and print remaining all elemnts
print(set1.symmetric_difference(set2))
#isdisjoint - no common elements
s1={1,2,3}
s2={4,5,6}
print(s1.isdisjoint(s2)) 
print(s2.isdisjoint(s1))
s1={1,2,3}
s2={1,2,3,4,5}
print(s1.isdisjoint(s2))
print(s2.isdisjoint(s1))
#subset
t1={2.0,3.0,4.0}
t2={10,20,30,2.0,3.0,4.0,5.0,6}
print(t1.issubset(t2))  # all elments of set1  should be in set2
w1={1,2,3,4,5,6,7,8}
w2={1,2,3}
print(w1.issuperset(w2)) #true if all elemnts of w2 set present in w1 set
print(w2.issuperset(w1)) 
#set using for loop
for j in {1,10,2,3,4,5,1}:
    if j==1:
        print("Yes")
    else:
        print("No")   
        
#Frozen Set : Freezes data -mutable --> immutable we cannot make changes to data like append,add..etc
a=[10,20,30,40,50]
b=frozenset(a)
print(b)
h=[12,22,33,44]
print(type(h))
d=frozenset(h)
print(d)
h={12,22,33,44}
print(type(h))
d=frozenset(h)
print(d) 
print(list(d))      
                