'''
WAP to calculate the sum of all numbers from 1 to
Print first 10 natural numbers using for loop
'''
# for i in range(1,10+1):
#     print(i)


'''
TO print all even nbrs within range
'''
# r=int(input("Enter range:"))
# for i in range(r):
#     if i%2==0:
#         print(i)

'''
Program to calculate sum of all numbers from 1 to given number
'''
# n=int(input("Enter NO:"))
# s=0
# for i in range(1,n+1):
#     s=s+i
# print(s)    


'''
WAP to calculate the sum of all odd numbers from 1 to given number.
'''
# n=int(input("Enter range:"))
# s=0
# for i in range(n):
#     if i%2!=0:
#         s=s+i
# print(s) 

'''
TO count no of even  and odd numbers from a series of numbers
'''
# l=[1,2,3,4,5,6,7,8,9,10]
# ce=0
# co=0
# for i in l:
#     if i%2==0:
#         ce=ce+1
#     else:
#         co=co+1
# print("Number of Evens:",ce)
# print("Number Of Odds:",co)            

'''
To print multiplication table of given nbr
'''
# n=int(input("Enter TABLE:"))
# for i in range(1,10+1):
#     print(n,"x",i,"=",n*i)


'''
Python program to display numbers from a list using for loop
'''
# l=[1,2,3,4,5,6,7,8,9,10]
# for i in l:
#     print(i)

'''
TO count the total nummber of digits in a number
'''
# n=int(input("Enter number"))
# count=0
# while(n>0):
#     r=n%10
#     if r<=9:
#         count=count+1
#         n=n//10
# print(count)   

'''
To display all numbers within range except the prime numbers
'''
