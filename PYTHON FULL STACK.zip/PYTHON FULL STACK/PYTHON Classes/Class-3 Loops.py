'''
While Loop: It is used when the number of iterations are unknown
'''

# # while True:
#     # print("This is while")

# while False:
#     print("This is loop")
# else:
#     print("This is else")

# #Program
# i=10
# print()
# while i<20:
#     print("This is while",i)
#     i+=1
'''
# For Loop: It is used when the number of iterations are known.
'''
# print()    
# for i in "swarna":
#     print(i) 

# print()
# for m in range(11):
#     print(m) 

# print()
# for j in range(0,11):
#     print(j)           
 
# print()
# for k in range(0,11,2):   
#     print(k)

# print()
# for l in range(0,11,1): #no gap n-1 1-1=0
#     print(l)    

# for i in range(5,0,-1):
#     print(i)    

for i in range(5,0,-2):
    print(i)
