# Encapsulation: Wrapping/Binding of data together
# binding of class (methods and variables(attributes))
# # public : Accessed by anyone. ex: RTC bus
# # and 
# # private --> '__' : Only single person . Ex: Our own vwhicle like car,bike
# # protected --> '_' :Only Inheritance can access

'''
# __init__ function: used to initialize the attributes of an object as soon as the object is formed.
class GFather:
    def __init__(self,a):
        self._y=a
        print(self._y)  # protected _ so accesed by their inheitance(gfather,father,child)
class Father(GFather):
    def display1(self):
        print(self._y)
class Child2(Father):
    def display2(self):
        print("child2",self._y)
obj=Child2(12)
obj.display2()
obj.display1()

# Error
class GFather:
    def __init__(self,a):
        self.__y=a
        print(self.__y)
class Father(GFather):
    def display1(self):
        print(self.__y)
class Child2(Father):
    def display2(self):
        print("child2",self.__y)
obj=Child2(12)
obj.display2()
obj.display1()
'''

# Abstraction: Hiding internal things and showing functionality.
'''
Abstract method there is no body
Abstract base class can not  create object
Abstract Class: A class which contains abstract methods.
Abstract Methods: Method with declaration but not the definition.
Abstract Base Class(abc):A class contain one or more abstract methods then it said to be a abc
'''

# Python program demonstrate  
# abstract base class work  


from abc import ABC, abstractmethod   
class Car(ABC):          # Abstract base class
    @abstractmethod      #Decorator(@abstractmethod):all properties in abstractmethod are accessed to milage fun
    def mileage(self):   
        pass   
class Tesla(Car):   
    def mileage(self):   
        print("The mileage is 30kmph")   
class Suzuki(Car):   
    def mileage(self):   
        print("The mileage is 25kmph ")   
class Duster(Car):   
     def mileage(self):   
          print("The mileage is 24kmph ")   
class Renault(Car):   
    def mileage(self):   
            print("The mileage is 27kmph ")           
# Driver code
t= Tesla ()   
t.mileage()   
r = Renault()   
r.mileage()    
s = Suzuki()   
s.mileage()   
d = Duster()   
d.mileage()  




# strings=input("Enter the String")
# print("palindorm") if strings==strings[::-1] else print("not a palindorm")
