a=20
print(a)

#single value with multiple variables
b=c=d=100
print(b,c,d)

#single variable with multiple values - default take as tuple
s=1,2,3
print(s)

a,b,c=1,2,3
print(a,b,c)

#Variables Rules
hell=16
print(hell)
hell123='A'
print(hell123)
heaven="heaven"
print(heaven)
Heaven=18
print(Heaven)
s_=7
print(s_)
_s=8
print(_s)

#1a=12
#h@=34

#To know address of a varaible
j=11
print(id(j))
#same value bt different variable gives same address
k=11  
print(id(k))
l=12
print(id(l))

#same variable bt different values gives same address
a=20
a=30
print(id(a))
print(id(a))
