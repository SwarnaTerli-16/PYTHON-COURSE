# Local: accessed within local
# Global: Accessed by anyone
a=10
def func():
    b=20
    print('this is fun',b,a)
func()
print(a)


a=10              #OP:   # this is fun 20 20
def func():              # 10
    a=20
    print('this is fun',a,a)  
func()
print(a)
    

# ERROR
# a=1
# def fun(a):
#     b=2
#     print(a)
#     print(b)
# print(b)    
# fun(a)    

    
    