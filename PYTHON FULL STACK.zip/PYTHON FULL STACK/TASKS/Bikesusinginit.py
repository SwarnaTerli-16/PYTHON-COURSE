class Bikes:
    def __init__(self,BikeName,BikeMilage,Cost):
        self.bname=BikeName
        self.bmile=BikeMilage
        self.cst=Cost
    def Output(self): 
        print()   
        print("Bike Name:",self.bname)
        print("Bike Milage:",self.bmile)
        print("Bike Cost:",self.cst)
bikename=input("Enter Bike Name:")  
bikemil=input("Enter Bike Milage:") 
bikecst=input("Enter Bike cost:")  

bikeobj=Bikes(bikename,bikemil,bikecst)
bikeobj.Output()        
  
# OR  

class Bikes:
    def __init__(self,BikeName,BikeMilage,Cost):
        self.bname=BikeName
        self.bmile=BikeMilage
        self.cst=Cost
    def Output(self):    
        print("Bike Name:",self.bname)
        print("Bike Milage:",self.bmile)
        print("Bike Cost:",self.cst)
bikeobj=Bikes("NS 200",60,150000)
bikeobj.Output()         
