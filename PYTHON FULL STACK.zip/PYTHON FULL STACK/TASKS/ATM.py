s='''
  1.credit
  2.Debit
  3.Mini Statement
  4.Exit
'''
name="swarna"
pw="123"
un=input("enter name")
upw=input("enter password")
amount=2000
if name==un and pw==upw:
    while(True):
        print(s)
        option=int(input("enter option:"))
        if option==1:
            credit_amount=float(input("enter amount"))
            print("amouunt after credit",amount+credit_amount)
        elif option==2:
            debit_amount=float(input("enter amount"))
            print("amouunt after debit",amount-debit_amount)
        elif option==3:
            print("***Mini Statement***",amount)        
        elif option==4:
            break           
else:
    print("incorrect")    