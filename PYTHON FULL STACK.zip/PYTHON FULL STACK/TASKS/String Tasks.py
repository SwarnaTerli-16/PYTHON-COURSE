


str = '''The cat is sleeping on the mat, enjoying the warmth from the sunlight streaming through the window.The sun is shining brightly in the sky, casting its golden rays upon the bustling city streets.People are walking briskly, immersed in their daily routines, while cars are honking amidst the traffic.'''

# Replacing 'is' and 'Is' with 'are'
text = str.replace(' is ', ' are ').replace(' Is ', ' are ')

# Replacing 'the' and 'The' with 'that'
text = str.replace(' the ', ' that ').replace('The ', 'that ')

print(text)
