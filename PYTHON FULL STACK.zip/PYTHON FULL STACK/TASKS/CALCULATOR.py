l='''
 1.add
 2.sub
 3.mul
 4.div
''' 
def add(a,b):
    print(a+b)
def sub(a,b):
    print(a-b) 
def mul(a,b):
    print(a*b) 
def div(a,b):
    print(a/b)            
inpt=input("enter user requirement:")
if inpt=='1' or inpt=='2' or inpt=='3' or inpt=='4':
    m,n=input("Enter values:").split()
    m=int(m)
    n=int(n)
    if inpt=='1':
        add(m,n)
    elif inpt=='2':
        sub(m,n)
    elif inpt=='3':    
        mul(m,n)
    elif inpt=='4':         
        div(m,n)
else:
    print("Invalid error")    



#elif inpt=='4':
#    if n!=0:    
#        div(m,n) 
#    else:
#        print(""Error! Division by zero is not allowed."")                 