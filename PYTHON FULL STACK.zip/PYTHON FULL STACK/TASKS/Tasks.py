#task 6
#write a python program on (a+b)**2

a=2
b=4
c=(a+b)**2
c= a**2+2*a*b+b**2
print("(a+b)**2 = ",c)

a=1
b=2
c = a**2 + b**2 + (2*a*b)
print(c)

#task 5
#Write a python program on Compond Intrest and Simple intrest.

p=1000
r=10
t=2
A=p*(1+r/100)**t
print("Compound Interest:",A)

p=1000
t=180
r=5
si=(p*t*r)/100
print("Simple Interest:",si)
