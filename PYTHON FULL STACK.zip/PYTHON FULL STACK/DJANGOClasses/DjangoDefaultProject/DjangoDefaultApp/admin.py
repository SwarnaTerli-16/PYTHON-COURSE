from django.contrib import admin

# Register your models here.
# ME
from DjangoDefaultApp.models import DemoModel
admin.site.register(DemoModel)
