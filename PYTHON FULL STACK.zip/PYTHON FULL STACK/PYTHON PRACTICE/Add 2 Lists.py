# Add two lists using map and lambda

l1=[1,2,3]
l2=[4,5,6]
result=map(lambda x,y : x+y ,l1,l2)
print(list(result))



# map function:map(function, iterables)
def myfunc(a, b):
  return a + b
x = map(myfunc, ('apple', 'banana', 'cherry'), ('orange', 'lemon', 'pineapple'))



