# for i in range(1,10+1):
#     mul=2*i
#     print("2","x",i,"=",mul)


table=int(input("Enter table:"))
for i in range(1,10+1):
    mul=table*i
    print(table,"x",i,"=",mul)
