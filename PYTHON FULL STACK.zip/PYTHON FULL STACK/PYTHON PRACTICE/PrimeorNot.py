# Python program to compute all the permutations(possibilities) of a string

n=int(input("Enter a nbr:"))
count=0
for i in range(1,n+1):
    if n%i==0:
        count+=1
if count==2:
    print("prime") 
else:
    print("not prime")           

# #Max Range:
# min=int(input("enter min nbr:"))
# max=int(input("enter max nbr:")) 
# for i in range(min,max+1):
#         count=0            #within range so count=0 inside the loop becoz when moving to a new nbr the count needs to start from zero
#         for j in range(1,i+1):
#             if i%j==0:
#                 count+=1       
#         if count==2:
#             print(f"{i}prime")
#         else:
#             print(f"{i}not prime")            
       