pyr=int(input("Enter present year:"))
dobyr=int(input("Enter dob year:"))
age=pyr-dobyr
print(f"Age of a person is {age} yrs")