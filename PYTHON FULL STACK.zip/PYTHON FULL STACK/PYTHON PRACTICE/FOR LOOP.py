# OP: Print 0 to 9 
n=10
for i in range(n):
    print(i)


# OP:Print 1 to 9
for i in range(1,10):
    print(i)


