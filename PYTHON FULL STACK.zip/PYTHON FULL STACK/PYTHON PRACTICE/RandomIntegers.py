# Write a Numpy Program to generate random integers between 1 to 300
import numpy as np 
x=np.random.randint(low=1,high=300)
print(x)


import numpy as np 
x=np.random.randint(low=1,high=300,size=10)
print(x)



