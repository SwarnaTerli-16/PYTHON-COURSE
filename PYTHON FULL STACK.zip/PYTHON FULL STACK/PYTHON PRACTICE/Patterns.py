# # 1) Square Pattern
# '''
# * * * * * 

# * * * * * 

# * * * * *

# * * * * *

# * * * * *
# '''
# n=int(input("Enter rows:"))
# for i in range(n):            # OUERLOOP # ROWS
#     for j in range(n):        # INNER LOOP # COLUMNS
#         print("*",end=" ")
#     print("\n")                # OUTER LOOP PRINT STATEMENT
# # OR
# '''
# *****

# *****

# *****

# *****

# *****
# '''    
# n=int(input("Enter rows:"))
# for i in range(n):
#     for j in range(n):
#         print("*",end="")
#     print("\n")
  
        

# #2) HALF PYRAMID
# # Increasing Order
# '''
# *
# * *
# * * *
# * * * *
# * * * * *
# '''
# n=int(input("enter nbr of rows:"))
# for i in range(n):               
#     for j in range(i+1):
#         print("*",end=" ")
#     print("")    
 


# # 3) HALF PYRAMID
# # Decreasing    
# '''
# * * * * * 
# * * * * 
# * * * 
# * * 
# *
# '''
# n=int(input("Enter rows:"))
# for i in range(n):
#     for j in range(i,n):  # for j in range(n-i)
#         print("*",end=" ")
#     print()  

 




#4) # Right sided traingle
# '''
#           * 
#         * * 
#       * * * 
#     * * * * 
#   * * * * *
# '''
# n=int(input("Enter rows:"))
# for i in range(n):
#     for j in range(i,n):
#         print(" ",end=" ")
#     for j in range(i+1):    
#         print("*",end=" ")
#     print()    
 
# # 5) Right Sided Triangle
# # 1.Increasing Space
# # 2.Decreasing Star
# '''
#   * * * * * 
#     * * * * 
#       * * * 
#         * * 
#           *
# '''
# n=int(input("Enter rows:"))
# for i in range(n):
#     for j in range(i+1):
#         print(" ",end=" ")
#     for j in range(i,n):
#         print("*",end=" ")
#     print()        




'''
     * 
    * * 
   * * * 
  * * * * 
 * * * * *
'''


# n=int(input("Enter no of rows:"))
# for i in range(n):
#     print(" "*(n-i-1),end=" ")
#     print("* "*(i+1))



# #6) Pyramid
# '''
#           * 
#         * * * 
#       * * * * * 
#     * * * * * * * 
#   * * * * * * * * *
# '''
# n=int(input("Enter rows:"))
# for i in range(n):
#     for j in range(i,n):
#         print(" ",end=" ")
#     for j in range(i):    
#         print("*",end=" ")
#     for j in range(i+1):
#         print("*",end=" ")    
#     print()    
 



