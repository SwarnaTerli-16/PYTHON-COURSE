# for i in range(0,100):
#     if i%7==0 and i%5!=0:
#         print(i)


# l=[]
# for i in range(0,100):
#     if i%7==0 and i%5!=0:
#         l.append(i)
# print(l)

# # join: list into string
# # split: string into list
# l=[]
# for i in range(0,100):
#     if i%7==0 and i%5!=0:
#         l.append(str(i))
# print(','.join(l))


for i in range(0,10):
    print(i)


