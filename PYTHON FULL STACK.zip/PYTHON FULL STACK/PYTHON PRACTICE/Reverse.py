n=12345
rev=0
while(n>0):
    r=n%10
    rev=(rev*10)+r
    n=n//10
print(rev)    


# using slicing
n=123
s=str(n)[::-1]
print(s)
print(type(s))