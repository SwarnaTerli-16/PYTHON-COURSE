#square of the number 
n=input("ENter numbers:").split()
squares=[]
for no in n:
    num=int(no)
    sq=num*num
    squares.append(sq)
print("Squares of  Numbers:",squares)    
