marks=int(input("Enter marks:"))
if marks>=85 and marks<=100:
    print(" CONGRATS! A GRADE")
elif marks>=70 and marks<=85:
    print("You scored B GRADE")
elif marks>=60 and marks<=70:
    print("You scored C GRADE")  
elif marks>=40   and marks<=60:
    print("You scored D GRADE")    
else:
    print("Sorry,you are fail")       