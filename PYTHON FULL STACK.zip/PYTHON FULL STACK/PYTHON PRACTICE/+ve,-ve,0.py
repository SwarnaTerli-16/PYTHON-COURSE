'''
n=int(input("Enter nbr:"))
if n>0:
    print("positive")
elif n<0:
    print("Negative")
else:
    print("Whole nbr")    
'''

nbrs=input("Enter nbr:").split()
for nbr in nbrs:
    num=int(nbr)
    if num>0:
        print(" {} positive".format(num))
    elif num<0:
        print(f"{num} Negative")
    else:
        print(f"{num}Whole nbr")    

