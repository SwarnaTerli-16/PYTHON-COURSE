n=int(input("enter age:"))
if n>=18:
    print("Eligible for voting")
else:
    print("Sorry,Not ELigible for voting")    