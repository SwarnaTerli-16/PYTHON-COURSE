a=input("enter a numbers:")
b=input("enter b numbers:")
c=input("enter c numbers:")
if a>b and a>c:
    print("A is largest",a)
elif b>a and b>c:
    print("B is largest",b) 
else:
    print("C is largest",c)      
