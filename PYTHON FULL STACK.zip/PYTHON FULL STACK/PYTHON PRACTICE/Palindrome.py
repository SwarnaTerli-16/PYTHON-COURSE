# n=int(input("Enter nbr:"))
# rev=0
# temp=n
# while(temp>0):
#     r= temp%10
#     rev=(rev*10)+r
#     temp=temp//10
# print(f"Reversed number of {rev} is:",rev)    
# if n==rev:
#     print("Palindrome")
# else:
#     print("Not palindrome")    


'''
Generate a list of squares of palindrome numbers 
between 1 and 1000 using list comprehension.
'''
pal=[x**2 for x in range(1,100) if str(x**2)==str(x**2)[::-1]]
print(pal)

'''
if str(x**2) == str(x**2)[::-1]: This is a condition that checks if the square of x is equal to its reverse.

str(x**2): This converts the square of x into a string.
str(x**2)[::-1]: This reverses the string representation of the square of x.
==: This checks if the original string and its reverse are equal, indicating that the square is a palindrome.
'''