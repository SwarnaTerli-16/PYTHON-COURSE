dict={1:'swarna','Branch':'CSE',3:'Vasavi','Branch':'EEE'}
print(dict.items())


dict={1:'swarna','Branch':'CSE',3:'Vasavi','Branch':'EEE'}
for i,j in dict.items():
    print(i,j)



