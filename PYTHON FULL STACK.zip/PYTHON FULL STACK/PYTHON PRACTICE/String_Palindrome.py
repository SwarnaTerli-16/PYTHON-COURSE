s="mom"
print(s[::-1])

n=input("Enter string:")
str=n[::-1]
print(str)

# strings=input("Enter the String")
# print("palindorm") if strings==strings[::-1] else print("not a palindorm")

def is_palindrome(s):
    return s==s[::-1]
str=input("Enter string:")
res=is_palindrome(str)
if res:
    print("Palindrome")
else:
    print("Not a Palindrome")    

# OR

def is_palindrome(s):
    return s == s[::-1]
s=input("Enter string:")
res=is_palindrome(s)
if res:
    print("Palindrome")
else:
    print("Not a Palindrome")        


# OR
def is_palindrome(s):
    return s == s[::-1]
s = input("Enter string: ")
if is_palindrome(s):
    print("Palindrome")
else:
    print("Not a Palindrome")

# OR    
# If string contains empty spaces
def is_palindrome(s):
    # Remove spaces and convert to lowercase for case-insensitive palindrome check
    s = s.replace(" ", "").lower()
    return s == s[::-1]
# Get user input
user_input = input("Enter a string: ")
if is_palindrome(user_input):
    print("The string is a palindrome.")
else:
    print("The string is not a palindrome.")


