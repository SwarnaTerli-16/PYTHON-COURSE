#  Write a python program to detect the number of  local variables 
#  declared in a function.

c=1
def kiran():
    a=10
    b=20.33
    s="kiran"
print(kiran.__code__.co_nlocals)  

# front lo 2 lines end lo 2 lines unte constructor antaru.   