punctations="/''\,.!()@%$*&+_?"
str=input("Enter string:")
new_str=""
for s in str:
    if s not in punctations:
        new_str += s
print(new_str)   

# Manual Removal
import string
def rem_pun(str):
    result_str=''.join(char for char in str if char not in string.punctuation)
    return result_str
org_str=input("Enter tring:")
clear_str=rem_pun(org_str) 
print("Clear String:",clear_str)   






# # With Append
# punctuations = "/''\,.!()@%$*&+_?"
# input_str = input("Enter string:")
# new_str = []

# for char in input_str:
#     if char not in punctuations:
#         new_str.append(char)

# result = ''.join(new_str)
# print(result)






# # Using string.translate method:
# import string
# def remove_punctuation(input_string):
#     # Create a translation table
#     translator = str.maketrans("", "", string.punctuation)
#     # Use translate to remove punctuation
#     result_string = input_string.translate(translator)    
#     return result_string
# # Example usage:
# input_text = "Hello, World! This is an example text."
# cleaned_text = remove_punctuation(input_text)
# print("Original text:", input_text)
# print("Text without punctuation:", cleaned_text)

# #Manual removal of punctuation:
# import string
# def remove_punctuation_manually(input_string):
#     result_string = ''.join(char for char in input_string if char not in string.punctuation)
#     return result_string
# # Example usage:
# input_text = "Hello, World! This is an example text."
# cleaned_text = remove_punctuation_manually(input_text)
# print("Original text:", input_text)
# print("Text without punctuation:", cleaned_text)


 

