a=0
b=1
for i in range(1,10+1):
    c=a+b
    a=c
    b=a
    print(c)

#fibonacci seies using recursion
# def fib(n):
#     if n==1 or n==2:
#         return 1
#     else:
#         return(fib(n-1)+fib(n=2))  
# print(fib(7))



# def fibonacci_recursive(n):
#     if n <= 1:
#         return n
#     else:
#         return fibonacci_recursive(n-1) + fibonacci_recursive(n-2)

# # Example usage:
# num_terms = 10
# fibonacci_sequence = [fibonacci_recursive(i) for i in range(num_terms)]

# print("Fibonacci Series (First", num_terms, "terms):", fibonacci_sequence)

    
