# Actual Method:
n=int(input("enter a nbr:"))
fact=1
for i in range(1,n+1):
    res=fact*i
    fact=res
print(f"Factorial of a {n} is:",res)    


# Easy Method:
n=5
fact=1
for i in range(1,5+1): 
    fact=fact*i
print(fact)


# Using if else
n=int(input("enter a nbr:"))
fact=1
if n>0: 
    for i in range(1,n+1):
        res=fact*i
        fact=res
    print(f"Factorial of a {n} is:",res) 
else:
    print(f"Factorial of {n} is 1")        


