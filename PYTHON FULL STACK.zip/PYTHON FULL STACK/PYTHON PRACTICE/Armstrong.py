'''
n=153
temp=n
sum=0
while(temp>0):
    r=temp%10
    c=r*r*r
    sum+=c
    temp=temp//10
print(sum)    
if n==sum:
    print("Armstrong nbr")
else:
    print("Not Armstrong nbr")        
'''
n=153
temp=n
sum=0
while(temp>0):
    r=temp%10
    sum=sum+(r*r*r)
    temp=temp//10
print(sum)    
if n==sum:
    print("Armstrong nbr")
else:
    print("Not Armstrong nbr")            