# Area of circle=pie*r*r

r=float(input("Enter radius:"))
pie=3.14
a=pie*r*r
print("Area of circle:",a)

# OR

# In this program we cannot use ternary operator becoz- it is used only when there is only single statement in if and else.
# Ternary Operator: it is used only when there is only single statement in if and else.

# Finding area of circle using if else, radius cannot be zero or negative .
r=float(input("Enter radius:"))
pie=3.14
if r>0:
    a=pie*r*r                      # 2 statements
    print("Area of circle:",a)
else:
    print("Cannot print area") 


# OR
import math
r=float(input("Enter radius:"))
a=math.pi*r*r
print("Area of circle:",a)    
