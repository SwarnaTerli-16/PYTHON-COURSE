# total=0
# l1=[10,20,30,40,50,60]
# for x in l1:
#     total += x
# print(total)    


# With functions 
def sum(numbrs):
    total=0
    for x in numbrs:
        total+=x
    return total
print(sum([10,20,30,40,50,60])) 


    
# With functions 
total = 0  # This line is executed before calling the function
def sum(numbrs):
    global total  # Use the 'global' keyword to refer to the outer 'total' variable
    for x in numbrs:
        total += x
    return total
print("Total before function call:", total)
print("Total after function call:", sum([10, 20, 30, 40, 50, 60]))    