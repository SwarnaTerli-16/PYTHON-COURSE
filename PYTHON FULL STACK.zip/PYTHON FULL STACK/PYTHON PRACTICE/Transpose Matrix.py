# Transpose matrix using Nested Loop

# TRANSPOOSE : rows ---> columns,columns --> rows
# USING NUMPY
# x=[[1,2,3],
#    [4,5,6],
#    [7,8,9]]
# import numpy as np 
# c=np.transpose(x)
# print(c)




x=[[1,2,3],
   [4,5,6],
   [7,8,9]]
result = [[0,0,0],
          [0,0,0],
         [0,0,0]]
for i in range(len(x)):
    for j in range(len(x[0])):
        result[j][i] = x[i][j]
for r in result:
    print(r)        
