# n=int(input("Enter no:"))
# if n%2==0:
#     print("Even")
# else:
#     print("odd")

n=input("Enter numbers:").split()
for num in n:
    no=int(num)
    if no%2==0:
        print(f"{no} Even")
    else:
        print(" {} Odd ".format(no))    
