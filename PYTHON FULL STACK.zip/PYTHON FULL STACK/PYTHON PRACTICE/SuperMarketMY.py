from datetime import datetime
print("----------------------------Welcome---------------------------")
name=input("Enter Your Name:")
lists='''
Rice     Rs   20/kg
Sugar    Rs   30/kg
Salt     Rs   20/kg
Oil      Rs   80/Liter
Panner   Rs   110/kg
Maggi    Rs   50/kg
Boost    Rs   90/Each
Colgate  Rs   85/each
'''

price=0
totalprice=0
finalamount=0
pricelist=[]
ilist=[]
qlist=[]
plist=[]

items={'Rice':20,
       'Sugar':30,'Salt':20,'Oil':80,
       'Panner':110,'Maggi':50,
       'Boost':90,'Colgate':85}

option=int(input("For List Of Items Press 1:"))
if option==1:
    print(lists)

for i in range(len(items)):
    inp1=int(input("If you want to buy press 1 OR press 2 for exit:"))
    if inp1==2:
        print("EXIT")
        break
    if inp1==1:
        item=input("Enter your items:")
        qty=int(input("Enter Quantity:"))
        if item in items.keys():
            price=qty*(items[item])
            #print("Amount:",price)
            pricelist.append((item,price,qty))
            #print("Item Names,No of quantity,Price:",pricelist)
            totalprice+=price
            #print("TOTAL PRICE:",price)
            ilist.append(item)
            #print(ilist)
            qlist.append(qty)
            #print(qlist)
            plist.append(price)
            #print(plist)
            gst=(totalprice*5)/100
            finalamount=gst+totalprice
            #print("Final Amount",finalamount)
        else:
            print("sorry you enered item is not available")
    else:
        print("you entered wrong number")
    opt=input("Can i bill the items yes or no:")
    if opt=='yes' or opt=='Yes':
        pass
        if finalamount!=0:
            print(25*"=","Radhe SuperMarket",25*"=")
            print(28*" ","ANAND CENTER")
            print("Name:",name,30*" ","Date:",datetime.now())
            print(75*"-")
            print("sno",8*" ",'items',6*" ",'quantity',6*" ",'price')
            for i in range(len(pricelist)):
                print(i,8*' ',5*' ',ilist[i],3*' ',qlist[i],8*" ",plist[i])
            print(75*"-")    
            print(50*" ",'TotalAmount:','Rs',totalprice)
            print(50*" ","gstAmount:",'Rs',gst)
            print(75*"-")
            print(50*" ",'finalAmount:','Rs',finalamount)
            print(75*"-")
            print(20*" ","Thanks for visiting")
            print(75*"-")
            