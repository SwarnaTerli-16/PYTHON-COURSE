# Area of side: s*S
# or Area = l*b
# Perimeter of square: 4 * s

# s=float(input("Enter side of square:"))
# a=s*s
# p=4*s
# print("Area of square:",a)
# print("Perimeter of square:",p)


# s=float(input("Enter side of square:"))
# a=s*s
# p=4*s
# print(f"Area of square: %f"%a)
# print(f"Area of square: %.2f"%a)
# print("Perimeter of square:",p)

s=float(input("Enter side of square:"))
a=s*s
p=4*s
if s>0:
    print("Area of square:",a)
    print("Perimeter of square:",p)
else:
    print("Cannot find area")    

