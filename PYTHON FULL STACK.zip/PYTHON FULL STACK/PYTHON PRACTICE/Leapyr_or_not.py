'''
n=int(input("Enter nbr"))
if n%4==0 or n%400==0:
    print("Leap yr")
else:
    print("Ordinary Year")        

'''

    
def checkYear(year):
    return (((year%4==0) and (year%100!=0)) or (year%400==0))
year=2001
if checkYear(year):
    print("Leap Yr")  
else:
    print("Not a leap yr")          