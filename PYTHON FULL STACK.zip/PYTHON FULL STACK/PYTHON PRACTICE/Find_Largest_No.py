a=int(input("Enter no:"))
b=int(input("Enter no:"))
c=int(input("Enter no:"))
if a>b and a>c:
    print(f"{a} is big")
elif b>a and b>c:
    print(f"{b} is big")
else:
    print(f"{c} is big")    

# OR
l=[10,30,20]
print(max(l))