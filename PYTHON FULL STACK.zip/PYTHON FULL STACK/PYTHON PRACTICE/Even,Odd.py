'''
nbrs=input("Enter nbr:").split()
for nbr in nbrs:
    num= int(nbr)
    if num %2 == 0:
        print(f"{num} is even")
    else:
        print("{} Odd".format(num))  
'''

# Ternary Operator: it is used only when there is only single statement in if and else.
# Ternary operator or short hand if else:
#syntax: [true_condition] if [expression] else [false_condition]  
n=int(input("enter nbr:"))
print("even") if n%2==0 else print("odd")        

         
         